export default function Contact() {
  return (
    <section id="contact" className="contact container">
      <h2>Contact</h2>
  <p>If you'd like to work together, send me an email at <a href="mailto:arifmd52627@gmail.com">arifmd52627@gmail.com</a></p>
    </section>
  )
}
